﻿function Repair-AttendanceTaskNames([string]$Root) {
    if(-not(Test-Path -LiteralPath (Join-Path $Root '출근정리_자동실행.exe'))){return}
    foreach($pair in @(@('자동출근','출근정리_출근',''),@('자동퇴근','출근정리_퇴근',''),@('자동출퇴근로그인','출근정리_로그인','--show-ui'),@('자동출퇴근점검','출근정리_점검','--watchdog'))) {
        $legacy=Get-ScheduledTask -TaskName $pair[0] -ErrorAction SilentlyContinue
        if(-not $legacy){continue}
        $action=@($legacy.Actions)[0]
        $prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
        if(-not(($action.Execute -and $action.Execute.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) -or ($action.Arguments -and $action.Arguments.IndexOf($prefix,[StringComparison]::OrdinalIgnoreCase) -ge 0))){continue}
        if(-not(Get-ScheduledTask -TaskName $pair[1] -ErrorAction SilentlyContinue)) {
            [xml]$xml=Export-ScheduledTask -TaskName $pair[0] -ErrorAction Stop
            $exec=$xml.SelectSingleNode('//*[local-name()="Actions"]/*[local-name()="Exec"]')
            if(-not $exec){throw '예약 작업 실행 정보를 확인할 수 없습니다.'}
            $exec.SelectSingleNode('*[local-name()="Command"]').InnerText=[string](Join-Path $Root '출근정리_자동실행.exe')
            $arguments=$exec.SelectSingleNode('*[local-name()="Arguments"]')
            if(-not $arguments){$arguments=$xml.CreateElement('Arguments',$exec.NamespaceURI);[void]$exec.AppendChild($arguments)}
            $arguments.InnerText=[string]$pair[2]
            [void](Register-ScheduledTask -TaskName $pair[1] -Xml $xml.OuterXml -ErrorAction Stop)
        }
        Unregister-ScheduledTask -TaskName $pair[0] -Confirm:$false -ErrorAction Stop
    }
}
