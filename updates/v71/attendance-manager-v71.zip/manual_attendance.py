"""Requery the site's records before completing missing manual attendance."""
from datetime import date, datetime, timedelta

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from attendance_recovery import AttendancePage, parse_time, is_blank_time, previous_workday
from attendance_changes import blocked


def clock(row, field):
    value = parse_time(row[field])
    if value is None and not is_blank_time(row[field]):
        raise RuntimeError(f'{field} 표시를 해석할 수 없어 저장하지 않았습니다.')
    return value


def sync_present(app, day, field, value):
    with app.file_lock('state'):
        state = app.load_json(app.STATE_FILE, {})
        run = state.setdefault('runs', {}).setdefault(str(day), {}).setdefault(field, {})
        run.update(status='success', site_time=f'{value[0]:02}:{value[1]:02}',
                   verified_at=datetime.now().isoformat(timespec='seconds'), origin='수동 실행 · 사이트 기록 확인')
        for key in ('last_error', 'retry_at'):
            run.pop(key, None)
        if field == 'checkout':
            state['repair_pending'] = [key for key in state.get('repair_pending', []) if key != str(day)]
        app.save_json(app.STATE_FILE, state)


def allowed(app, day):
    return app.is_workday(day) and not blocked(app.load_json(app.STATE_FILE, {}), day)


def sync_missing_checkout(app, day, target):
    with app.file_lock('state'):
        state = app.load_json(app.STATE_FILE, {})
        run = state.setdefault('runs', {}).setdefault(str(day), {}).setdefault('checkout', {})
        run.update(status='retryable', attempts=0, retry_at=target.isoformat(timespec='seconds'),
                   missing_verified_at=datetime.now().isoformat(timespec='seconds'))
        run.pop('last_error', None)
        app.save_json(app.STATE_FILE, state)


def fill_missing(app, page, day, field, target, today):
    # Re-read immediately before editing, and let AttendancePage.correct verify
    # that every other value and the note remain unchanged before submission.
    if date.today() != today or not app.automation_enabled(app.load_json(app.SETTINGS_FILE, {})) or not allowed(app, day):
        raise RuntimeError('날짜 또는 제외·실행 설정이 변경되어 저장을 보류했습니다.')
    if target.date() != day:
        raise RuntimeError('등록할 시간의 날짜가 대상 근무일과 달라 저장하지 않았습니다.')
    row = page.record(day)
    value = clock(row, field)
    if value is not None:
        sync_present(app, day, field, value)
        return '기존 기록 유지'
    if field == 'checkout' and clock(row, 'checkin') is None:
        return '출근 기록 없음 · 퇴근 생략'
    if field == 'checkin' and clock(row, 'checkout') is not None:
        return '퇴근 기록 있음 · 출근 추가 생략'
    try:
        if not page.correct(day, {field: target}, row):
            raise RuntimeError('등록 후 확인을 완료하지 못했습니다.')
        after = page.record(day)
        value = clock(after, field)
        if value != (target.hour, target.minute):
            raise RuntimeError('사이트에 저장된 시간이 예정 시간과 다릅니다.')
        sync_present(app, day, field, value)
        return '누락 등록 확인'
    except Exception as error:
        with app.file_lock('state'):
            state = app.load_json(app.STATE_FILE, {})
            run = state.setdefault('runs', {}).setdefault(str(day), {}).setdefault(field, {})
            run['status'] = 'uncertain' if getattr(page.driver, '_workday_write_submitted', False) else 'retryable'
            run['last_error'] = app.user_job_error(error, f'{day} {field} 누락 보완')
            if run['status'] == 'retryable':
                run['retry_at'] = (datetime.now() + timedelta(seconds=60)).isoformat(timespec='seconds')
            if field == 'checkout' and day < today:
                state['repair_pending'] = sorted(set(state.get('repair_pending', [])) | {str(day)})
            app.save_json(app.STATE_FILE, state)
        raise


def reconcile(app, page, today):
    messages = []
    row = page.record(today)
    checkin, checkout = clock(row, 'checkin'), clock(row, 'checkout')
    if checkout is not None:
        sync_present(app, today, 'checkout', checkout)
    if checkin is not None:
        sync_present(app, today, 'checkin', checkin)
        messages.append(f'오늘 출근 {checkin[0]:02}:{checkin[1]:02} · 기존 기록 유지')
    elif checkout is not None:
        messages.append('오늘 퇴근 기록이 있어 출근 추가 생략')
    else:
        state = app.load_json(app.STATE_FILE, {})
        saved = state.get('runs', {}).get(str(today), {}).get('checkin', {})
        target = datetime.fromisoformat(saved['target']) if saved.get('target') else datetime.now().replace(second=0, microsecond=0)
        messages.append('오늘 출근 · ' + fill_missing(app, page, today, 'checkin', target, today))

    # Today's checkout is filled only after its saved/configured target time.
    row = page.record(today)
    checkin, checkout = clock(row, 'checkin'), clock(row, 'checkout')
    if checkout is not None:
        sync_present(app, today, 'checkout', checkout)
        messages.append(f'오늘 퇴근 {checkout[0]:02}:{checkout[1]:02} · 기존 기록 유지')
    elif checkin is not None:
        target = app.recovery_target(today)
        if datetime.now() >= target:
            messages.append('오늘 퇴근 · ' + fill_missing(app, page, today, 'checkout', target, today))
        else:
            sync_missing_checkout(app, today, target)
            messages.append(f'오늘 퇴근 · {target:%H:%M} 예정, 아직 등록하지 않음')

    state = app.load_json(app.STATE_FILE, {})
    days = {previous_workday(today, lambda day: allowed(app, day))}
    days.update(date.fromisoformat(key) for key in state.get('repair_pending', []) if date.fromisoformat(key) < today)
    days.update(date.fromisoformat(key) for key, runs in state.get('runs', {}).items()
                if date.fromisoformat(key) < today and runs.get('checkin', {}).get('status') == 'success'
                and runs.get('checkout', {}).get('status') != 'success')
    for day in sorted(days):
        if not allowed(app, day):
            continue
        row = page.record(day)
        checkin, checkout = clock(row, 'checkin'), clock(row, 'checkout')
        if checkout is not None:
            sync_present(app, day, 'checkout', checkout)
            result = '기존 퇴근 유지'
        elif checkin is None:
            result = '출근 기록 없음 · 퇴근 생략'
        else:
            result = fill_missing(app, page, day, 'checkout', app.recovery_target(day), today)
        messages.append(f'{day} 퇴근 · {result}')
    return messages


def run(app):
    driver = None
    phase = '크롬·드라이버 시작'
    try:
        with app.file_lock('action', timeout=0):
            settings = app.load_json(app.SETTINGS_FILE, {})
            if not settings.get('id') or not settings.get('pw'):
                raise RuntimeError('먼저 ID/PW를 저장하세요.')
            today = date.today()
            if not app.automation_enabled(settings):
                raise RuntimeError('자동관리가 일시 정지되어 있습니다.')
            if not allowed(app, today):
                return {'ok': True, 'message': '오늘은 제외일이어서 등록하지 않았습니다.'}
            app._LOG_SECRETS.add(settings['pw'])
            driver = app.create_driver()
            driver.set_page_load_timeout(45)
            phase = '로그인 화면 확인'
            driver.get(app.SITE_URL)
            app.check_site_response(driver)
            wait = WebDriverWait(driver, 20)
            wait.until(EC.visibility_of_element_located((By.NAME, 'iduser'))).send_keys(settings['id'])
            driver.find_element(By.NAME, 'pass').send_keys(settings['pw'])
            phase = '로그인 후 근태관리 메뉴 확인'
            driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]').click()
            # The checkout link may be absent when checkout is already complete.
            wait.until(EC.element_to_be_clickable((By.LINK_TEXT, '근태관리')))
            app.check_site_response(driver)
            phase = '사이트 출퇴근 내역 확인·누락 보완'
            page = AttendancePage(driver, today)
            page.open()
            messages = reconcile(app, page, today)
            for message in messages:
                app.log_event(message)
            return {'ok': True, 'message': '\n'.join(messages)}
    except Exception as error:
        message = app.user_job_error(error, phase)
        app.log_event(message)
        return {'ok': False, 'message': message}
    finally:
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass
